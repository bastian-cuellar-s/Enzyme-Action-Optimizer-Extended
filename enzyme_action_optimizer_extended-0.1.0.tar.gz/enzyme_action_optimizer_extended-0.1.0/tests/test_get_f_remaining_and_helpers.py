import numpy as np


def test_get_f_remaining_functions():
    from utils.get_f import Get_F

    np.random.seed(0)
    remaining = ['F4','F6','F7','F11','F12','F13','F15','F16','F17','F18','F19','F20','F21','F22','F23']
    for name in remaining:
        lb, ub, dim, f = Get_F(name)
        # prepare x according to lb/ub/dim
        if isinstance(dim, int):
            x = np.zeros(dim)
        else:
            # fallback
            x = np.zeros(2)
        val = f(x)
        assert np.isfinite(val)


def test_helpers_get_best_agents_and_levy():
    from utils.helpers import get_best_agents, levy_flight

    pop = np.array([[1.0,2.0],[0.1,0.2],[3.0,4.0]])
    fitness = np.array([5.0, 0.1, 10.0])
    a,b,c = get_best_agents(pop, fitness)
    # best is index 1
    assert np.allclose(a, pop[1])
    # levy flight returns array of length D
    step = levy_flight(1.5, 2)
    assert step.shape == (2,)
    assert np.isfinite(step).all()


def test_metrics_edge_cases():
    from utils.metrics import calculate_metrics, wilcoxon_test
    import numpy as np

    data = [1.0, 1.0, 1.0]
    m = calculate_metrics(data)
    assert m['std'] == 0.0

    # wilcoxon on near-identical samples (use a small delta) to avoid divide-by-zero
    a = np.ones(10)
    b = np.ones(10) + 0.1
    stat, p = wilcoxon_test(a, b)
    assert np.isfinite(stat) and np.isfinite(p)
