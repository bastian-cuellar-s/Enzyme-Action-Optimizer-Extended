import numpy as np


def test_more_plots(tmp_path):
    from utils import plots

    out1 = tmp_path / 'balance.png'
    x = np.random.rand(10)
    y = np.random.rand(10)
    plots.exploration_exploitation_balance(x, y, str(out1))
    assert out1.exists()

    out2 = tmp_path / 'box.png'
    data = [np.random.rand(5), np.random.rand(5)]
    plots.comparative_boxplot(data, ['a','b'], str(out2))
    assert out2.exists()

    out3 = tmp_path / 'heat.png'
    mat = np.random.rand(3,3)
    plots.sensitivity_heatmap(mat, ['x1','x2','x3'], ['y1','y2','y3'], str(out3))
    assert out3.exists()
