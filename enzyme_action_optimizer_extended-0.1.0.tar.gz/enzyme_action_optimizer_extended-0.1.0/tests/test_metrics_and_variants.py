import numpy as np


def test_calculate_metrics():
    from utils.metrics import calculate_metrics

    data = [1.0, 2.0, 3.0, 4.0]
    m = calculate_metrics(data)
    assert m['mean'] == np.mean(data)
    assert m['best'] == min(data)
    assert m['worst'] == max(data)


def test_get_variant_func_smoke():
    from utils.eao_variants import get_variant_func

    func = get_variant_func('gwo')
    # should be callable
    assert callable(func)

    # eao special-case wrapper
    eao_func = get_variant_func('eao')
    assert callable(eao_func)
