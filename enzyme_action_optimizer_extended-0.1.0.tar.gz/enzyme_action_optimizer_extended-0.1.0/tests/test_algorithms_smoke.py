import numpy as np


def make_population(N, dim, lb=-1.0, ub=1.0):
    return np.random.uniform(lb, ub, size=(N, dim))


def test_iterar_gwo_smoke():
    from metaheuristics.GWO import iterar_GWO

    N = 5
    dim = 3
    pop = make_population(N, dim)
    fitness = np.array([np.sum(pop[i] ** 2) for i in range(N)])
    best = pop[np.argmin(fitness)]
    new_pop, new_fit = iterar_GWO(10, 0, dim, pop, fitness, best, -5, 5)
    assert new_pop.shape == (N, dim)
    assert new_fit.shape == (N,)
    assert np.all(new_fit >= 0)


def test_iterar_mvo_smoke():
    from metaheuristics.MVO import iterar_MVO

    N = 6
    dim = 4
    pop = make_population(N, dim)
    fitness = np.array([np.sum(pop[i] ** 2) for i in range(N)])
    best = pop[np.argmin(fitness)]
    new_pop, new_fit = iterar_MVO(20, 1, dim, pop, fitness, best, -3, 3)
    assert new_pop.shape == (N, dim)
    assert new_fit.shape == (N,)
    assert np.all(new_fit >= 0)


def test_iterar_pso_smoke():
    from metaheuristics.PSO import iterar_PSO

    N = 5
    dim = 3
    pop = make_population(N, dim)
    fitness = np.array([np.sum(pop[i] ** 2) for i in range(N)])
    best = pop[np.argmin(fitness)]
    velocity = np.zeros((N, dim))
    pbest = pop.copy()
    new_pop, new_fit, new_vel = iterar_PSO(15, 2, dim, pop, fitness, best, -2, 2, velocity, pbest)
    assert new_pop.shape == (N, dim)
    assert new_fit.shape == (N,)
    assert new_vel.shape == (N, dim)
    assert np.all(new_fit >= 0)
