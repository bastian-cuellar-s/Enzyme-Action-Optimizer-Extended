import numpy as np


def test_get_f_f1_basic():
    from utils.get_f import Get_F

    lb, ub, dim, f = Get_F('F1')
    # Check types and shapes
    assert isinstance(lb, (int, float))
    assert isinstance(ub, (int, float))
    assert isinstance(dim, int)
    # Evaluate f at zero vector: should be 0
    x = np.zeros(dim)
    val = f(x)
    assert np.isclose(val, 0.0)
