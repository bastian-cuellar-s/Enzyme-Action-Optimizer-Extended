import builtins
import os
from pathlib import Path


def test_plots_write_files(tmp_path):
    from utils import plots
    import numpy as np

    curvas = [np.random.rand(10), np.random.rand(10)]
    labels = ['a', 'b']
    out1 = tmp_path / 'curva.png'
    plots.convergence_curve(curvas, labels, str(out1))
    assert out1.exists()

    pop_hist = [np.random.rand(5, 2), np.random.rand(5, 2)]
    out2 = tmp_path / 'hist.png'
    plots.search_history(pop_hist, str(out2))
    assert out2.exists()


def test_main_short_run(tmp_path, monkeypatch):
    # Ensure working directory is repo root
    repo_root = Path.cwd()
    # Prepare inputs: EnzymeCount, MaxIter, Function, Variant
    inputs = iter(['5', '3', 'F1', 'gwo'])

    def fake_input(prompt=''):
        try:
            return next(inputs)
        except StopIteration:
            return ''

    monkeypatch.setattr(builtins, 'input', fake_input)

    # Use non-interactive backend for matplotlib to avoid GUI issues in CI
    import matplotlib
    matplotlib.use('Agg')
    # Run main
    import main
    # Run main; it will create results/ folder in repo root
    main.main()

    # Check that results/data and results/plots files exist for the run
    data_dir = repo_root / 'results' / 'data'
    plots_dir = repo_root / 'results' / 'plots'
    # Expect at least one CSV and one PNG
    csvs = list(data_dir.glob('*.csv'))
    pngs = list(plots_dir.glob('*.png'))
    assert csvs, f"No CSVs found in {data_dir}"
    assert pngs, f"No PNGs found in {plots_dir}"

    # Cleanup results to keep repo tidy
    import shutil

    shutil.rmtree(repo_root / 'results')
