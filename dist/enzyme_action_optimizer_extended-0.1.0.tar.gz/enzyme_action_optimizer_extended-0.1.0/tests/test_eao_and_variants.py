import numpy as np


def test_eao_basic():
    from metaheuristics.eao import EAO

    EnzymeCount = 4
    MaxIter = 3
    dim = 2
    lb = -1
    ub = 1

    def fobj(x):
        return np.sum(x ** 2)

    OptimalCatalysis, BestSubstrate, conv_curve = EAO(EnzymeCount, MaxIter, lb, ub, dim, fobj)
    assert isinstance(OptimalCatalysis, float) or isinstance(OptimalCatalysis, np.floating)
    assert BestSubstrate.shape == (dim,)
    assert conv_curve.shape[0] == MaxIter
    # BestSubstrate should be within bounds
    assert np.all(BestSubstrate >= lb - 1e-12)
    assert np.all(BestSubstrate <= ub + 1e-12)


def test_eao_wrapper_and_get_variant_func():
    from utils.eao_variants import get_variant_func

    wrapper = get_variant_func('eao')
    assert callable(wrapper)

    # Create a tiny population and fitness
    EnzymeCount = 3
    dim = 2
    population = np.zeros((EnzymeCount, dim))
    fitness = np.zeros(EnzymeCount)
    best = population[0, :].copy()
    lb = -0.5
    ub = 0.5

    new_pop, new_fit = wrapper(2, 0, dim, population, fitness, best, lb, ub)
    assert new_pop.shape == population.shape
    assert new_fit.shape == (EnzymeCount,)
    assert np.all(np.isfinite(new_fit))


def test_get_variant_func_invalid():
    from utils.eao_variants import get_variant_func
    import pytest

    with pytest.raises(ValueError):
        get_variant_func('this_variant_does_not_exist')
