import numpy as np


def test_get_f_f1_f2_f8_f9():
    from utils.get_f import Get_F

    for name in ('F1', 'F2', 'F8', 'F9'):
        lb, ub, dim, f = Get_F(name)
        # lb/ub can be scalars or arrays; create a zero vector within bounds
        if isinstance(lb, (list, tuple, np.ndarray)):
            lb_arr = np.array(lb)
            ub_arr = np.array(ub)
            x = (lb_arr + ub_arr) / 2.0
            # ensure dimension
            if x.size != dim:
                x = np.zeros(dim)
        else:
            x = np.zeros(dim)

        val = f(x)
        assert np.isfinite(val)
        # For F1 and F2 at zero vector expect 0
        if name == 'F1':
            assert np.isclose(val, 0.0)
        if name == 'F2':
            assert np.isclose(val, 0.0)


def test_get_f_additional():
    from utils.get_f import Get_F

    for name in ('F3', 'F5', 'F10', 'F14'):
        lb, ub, dim, f = Get_F(name)
        x = np.zeros(dim)
        val = f(x)
        assert np.isfinite(val)
